import * as t from "react-dom";
var o = "default" in t ? t.default : t;
var a = {};
var e = o;
a.createRoot = e.createRoot;
a.hydrateRoot = e.hydrateRoot;
const r = a.createRoot,
    d = a.hydrateRoot;
export {
    r as createRoot, a as
    default, d as hydrateRoot
};

//# sourceMappingURL=client.js.map