import {
    MotionValue
} from "framer";
export const isMotionValue = (v) => v instanceof MotionValue;

export const __FramerMetadata__ = {
    "exports": {
        "isMotionValue": {
            "type": "variable",
            "annotations": {
                "framerContractVersion": "1"
            }
        }
    }
}
//# sourceMappingURL=./isMotionValue.map