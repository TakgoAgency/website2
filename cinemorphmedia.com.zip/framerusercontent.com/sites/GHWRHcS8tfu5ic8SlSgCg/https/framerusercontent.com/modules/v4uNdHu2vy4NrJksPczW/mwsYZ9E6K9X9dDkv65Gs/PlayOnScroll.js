// PlayOnScroll override for Framer
import {
    jsx as _jsx
} from "react/jsx-runtime";
import * as React from "react";
export function PlayOnScroll() {
    const hostRef = React.useRef(null);
    React.useEffect(() => {
        let observer = null;
        let overlay = null; // helper to find the actual <video> element (Framer may wrap it)
        const findVideo = () => {
            if (!hostRef.current) return null;
            if (hostRef.current.tagName === "VIDEO") return hostRef.current;
            return hostRef.current.querySelector ? hostRef.current.querySelector("video") : null;
        }; // create a centered play overlay if autoplay is blocked
        const createOverlay = (container, video) => {
            if (!container || overlay) return;
            overlay = document.createElement("button");
            overlay.innerHTML = "▶";
            Object.assign(overlay.style, {
                position: "absolute",
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
                zIndex: 9999,
                background: "rgba(0,0,0,0.6)",
                color: "#fff",
                border: "none",
                padding: "12px 16px",
                borderRadius: "999px",
                cursor: "pointer",
                fontSize: "20px"
            });
            overlay.addEventListener("click", () => { // clicking is a user gesture — try to play and unmute if you want sound
                video.muted = false // optional: unmute on user click
                ;
                video.play().catch(() => {});
                overlay.style.display = "none";
            }); // ensure container is positioned relative so overlay sits correctly
            if (getComputedStyle(container).position === "static") {
                container.style.position = "relative";
            }
            container.appendChild(overlay);
        };
        const init = () => {
            const video = findVideo();
            if (!video) { // If the inner <video> is not rendered yet, retry shortly
                setTimeout(init, 100);
                return;
            } // Make it autoplay-friendly
            video.muted = true;
            video.playsInline = true;
            observer = new IntersectionObserver(([entry]) => {
                    if (entry.isIntersecting) { // try to play; if blocked, show overlay to let user start
                        video.play().catch(err => {
                            console.warn("Autoplay blocked:", err);
                            createOverlay(hostRef.current, video);
                            if (overlay) overlay.style.display = "block";
                        });
                    } else {
                        video.pause();
                    }
                }, {
                    threshold: .4
                } // tune this (0.2 earlier, 0.7 later)
            );
            observer.observe(video);
        };
        init();
        return () => {
            if (observer) observer.disconnect();
            if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
        };
    }, []); // return the host ref so Framer attaches it to your component
    return {
        ref: hostRef
    };
}
import {
    useContext as __legacyOverrideHOC_useContext
} from "react";
import {
    DataObserverContext as __legacyOverrideHOC_DataObserverContext
} from "framer";
export function withPlayOnScroll(C) {
    return props => {
        __legacyOverrideHOC_useContext(__legacyOverrideHOC_DataObserverContext);
        return _jsx(C, { ...props,
            ...PlayOnScroll(props)
        });
    };
}
withPlayOnScroll.displayName = "PlayOnScroll";
export const __FramerMetadata__ = {
    "exports": {
        "PlayOnScroll": {
            "type": "override",
            "name": "PlayOnScroll",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "withPlayOnScroll": {
            "type": "reactHoc",
            "name": "withPlayOnScroll",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}
//# sourceMappingURL=./PlayOnScroll.map