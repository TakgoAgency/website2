import {
    jsx as _jsx
} from "react/jsx-runtime";
export function withFourLineEllipsis(Component) {
    return props => {
        const newStyle = { ...props.style,
            display: "-webkit-box",
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
            WebkitLineClamp: 4,
            textOverflow: "ellipsis"
        };
        return /*#__PURE__*/ _jsx(Component, { ...props,
            style: newStyle
        });
    };
}
export const __FramerMetadata__ = {
    "exports": {
        "withFourLineEllipsis": {
            "type": "reactHoc",
            "name": "withFourLineEllipsis",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}
//# sourceMappingURL=./Overflow_text.map